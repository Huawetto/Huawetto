pip install requests
pip install beautifulsoup4
pip install tqdm
pip install colorama


