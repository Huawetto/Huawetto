import os
import re
import random
import requests
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor
from hashlib import md5
from colorama import init, Fore  # Aggiungi colorama per i colori

# Inizializza colorama
init(autoreset=True)

# Blacklist di parole chiave nei nomi dei file
BLACKLIST_KEYWORDS = [
    'youtube', 'yt', 'tiktok', 'tw', 'twitch', 'whatsapp', 'appstore', 'playstore', 
    'google', 'logo']

# Estensioni di file supportate
SUPPORTED_EXTENSIONS = {
    'images': ('.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.webp', '.tiff', '.ico'),
    'videos': ('.mp4', '.webm', '.avi', '.mov', '.mkv', '.flv', '.wmv', '.m4v'),
    'audio': ('.mp3', '.wav', '.aac', '.ogg', '.flac', '.m4a', '.wma'),
    'documents': ('.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.odt', '.ods', '.odp', '.csv'),
    'archives': ('.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz'),
    'scripts': ('.py', '.rb', '.java', '.c', '.cpp', '.cs', '.h', '.hpp', '.sh', '.bat'),
    'database_files': ('.sql', '.db', '.sqlite', '.mdb', '.accdb', '.dump'),
    'queries': ('.sql', '.query', '.rq', '.sparql'),
    'web_files': ('.html', '.htm', '.css', '.js', '.json', '.xml'),
    'machine_learning_models': ('.h5', '.pkl', '.joblib', '.pt', '.pth', '.onnx'),
    'code_archives': ('.tar.gz', '.zip', '.whl', '.egg'),
    'certificates': ('.pem', '.crt', '.key', '.pfx', '.der', '.cer', '.jks'),
    'logs': ('.log'),
    'configs': ('.ini', '.cfg', '.conf', '.yaml', '.yml'),
    'google_content': ('drive.google.com', 'docs.google.com', 'forms.google.com'),
}

# Pool di User-Agent per la rotazione
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 10; SM-G960F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/91.0.864.59',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Firefox/89.0',
    'Mozilla/5.0 (Linux; Android 11; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36'
]

# Tracker per evitare duplicati
visited_urls = set()
file_hashes = set()

# Funzione per creare cartelle in una struttura organizzata
def create_folder(base_folder, category, extension):
    folder_path = os.path.join(base_folder, category, extension or "no_extension")
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    return folder_path

# Genera un nome file unico con numeri casuali
def generate_unique_name(file_name, folder_path):
    base, ext = os.path.splitext(file_name)
    while True:
        random_suffix = f"_{random.randint(10000, 99999)}"
        new_file_name = f"{base}{random_suffix}{ext}"
        if not os.path.exists(os.path.join(folder_path, new_file_name)):
            return new_file_name

# Controlla se un file deve essere ignorato in base alla blacklist
def should_skip(file_name):
    lower_name = file_name.lower()
    return any(keyword in lower_name for keyword in BLACKLIST_KEYWORDS)

# Funzione per scaricare un file
def download_file(file_url, folder_path):
    try:
        file_name = os.path.basename(file_url.split("?")[0])
        
        # Controlla se il file è nella blacklist
        if should_skip(file_name):
            print(Fore.YELLOW + f"[-] Skipped (blacklist): {file_name}")
            return
        
        headers = {'User-Agent': random.choice(USER_AGENTS)}
        response = requests.get(file_url, stream=True, timeout=10, headers=headers)
        response.raise_for_status()

        file_name = generate_unique_name(file_name, folder_path)
        file_path = os.path.join(folder_path, file_name)

        # Evita duplicati basati sull'hash del contenuto
        content = response.content
        file_hash = md5(content).hexdigest()
        if file_hash in file_hashes:
            print(Fore.YELLOW + f"[-] Duplicate content skipped: {file_name}")
            return
        file_hashes.add(file_hash)

        # Salva il file
        with open(file_path, 'wb') as file:
            file.write(content)
        print(Fore.GREEN + f"[+] Downloaded: {file_name}")
    except Exception as e:
        print(Fore.RED + f"[-] Failed to download {file_url}: {e}")

# Scarica in parallelo i file
def download_parallel(links, base_folder, category):
    for link in links:
        ext = os.path.splitext(urlparse(link).path)[1].lstrip(".")
        folder_path = create_folder(base_folder, category, ext)
        download_file(link, folder_path)

# Funzione per analizzare una pagina e scaricare contenuti
def scrape_page(base_url, current_url, domain_folder):
    try:
        if current_url in visited_urls:
            return
        visited_urls.add(current_url)

        print(f"[+] Scraping: {current_url}")
        headers = {'User-Agent': random.choice(USER_AGENTS)}
        response = requests.get(current_url, timeout=10, headers=headers)
        response.raise_for_status()

        soup = BeautifulSoup(response.content, 'html.parser')
        resources = {key: set() for key in SUPPORTED_EXTENSIONS}

        # Raccogli file dalle risorse
        for tag in soup.find_all(['a', 'img', 'video', 'audio', 'source', 'link', 'script']):
            src = tag.get('href') or tag.get('src') or tag.get('data-src')
            if src:
                full_url = urljoin(base_url, src)
                parsed_url = urlparse(full_url)
                for category, extensions in SUPPORTED_EXTENSIONS.items():
                    if category == 'google_content' and any(domain in parsed_url.netloc for domain in extensions):
                        resources[category].add(full_url)
                    elif full_url.lower().endswith(extensions):
                        resources[category].add(full_url)
                        break

        # Scarica risorse per ogni categoria
        for category, links in resources.items():
            if links:
                download_parallel(links, domain_folder, category)

        # Trova link interni
        internal_links = set()
        for a_tag in soup.find_all('a', href=True):
            link = urljoin(base_url, a_tag['href'])
            if urlparse(link).netloc == urlparse(base_url).netloc:
                internal_links.add(link)

        # Visita i link interni
        for link in internal_links:
            scrape_page(base_url, link, domain_folder)

    except requests.exceptions.RequestException as e:
        print(Fore.RED + f"[-] Error accessing {current_url}: {e}")

# Funzione principale per avviare il web scraper
def scrape_all_content(base_url):
    try:
        domain_name = urlparse(base_url).netloc.replace('www.', '')
        base_folder = domain_name
        scrape_page(base_url, base_url, base_folder)
        print("\n[+] Scraping complete.")
    except Exception as e:
        print(Fore.RED + f"[-] An error occurred: {e}")

# Entry point
def main():
    print("=" * 71)
    print("||Advanced Website Content Scraper with Sub-Site Crawling by Huawetto||")
    print("=" * 71)
    url = input("Enter the website URL: ").strip()
    if not re.match(r'https?://', url):
        url = 'http://' + url
    scrape_all_content(url)

if __name__ == "__main__":
    main()
